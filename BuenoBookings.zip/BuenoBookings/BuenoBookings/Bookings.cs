﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace BuenoBookings
{
    public partial class Bookings : Form
    {
        private Form1 myParent;
        int GuestCurrentRecord = 0;
        int currentRecord = 0;
        bool addBook = false;
        bool editBook = false;
        bool deleteBook = false;
        DataTable dtGuests;
        DataTable dtRooms;
        DataTable dtHotels;
        DataTable dtBookings;

        public Bookings(Form1 p)
        {
            myParent = p;
            InitializeComponent();
        }

        private void Bookings_Load(object sender, EventArgs e)
        {
            FillHotelDropdown();
            LoadGuests();
            LoadBookings();
            FillRoom();
            PopulateFields();
            SetButtons(true);
            SetTexboxReadOnly(true);
            chkPreferred.Enabled = false;
            DisplayCurrentPosition();

        }
        #region MISC
        private string GetCurrentGuestId()
        {
            string GuestID = dtGuests.Rows[currentRecord]["GuestID"].ToString();
            return GuestID;
        }
        private void ResetForm()
        {
            //Resets the form and removes texts from textboxes
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            cboHotels.Text = string.Empty;
            cboRooms.Text = string.Empty;
            txtRoomNumber.Text = string.Empty;
            txtRate.Text = string.Empty;
            chkParking.Checked = false;

        }
        private void SetButtons(bool state)
        {
            btnBook.Enabled = state;
            btnEditBook.Enabled = state;
            btnDeleteBook.Enabled = state;
            btnCancel.Enabled = !state;
            btnSaveBook.Enabled = !state;
            btnNext.Visible = !state;
            btnFirst.Visible = !state;
            btnLast.Visible = !state;
            btnPrevious.Visible = !state;
        }

        private int CalculateCharge()
        {
            if(chkParking.Checked == true)
            {
                int Charge = Convert.ToInt32(dtRooms.Rows[currentRecord]["Rate"]) + Convert.ToInt32(dtRooms.Rows[currentRecord]["ParkingRate"]);
                return Charge;
            }
            else
            {
                int Charge = Convert.ToInt32(dtRooms.Rows[currentRecord]["Rate"]);
                return Charge;
            }
        }
        private int GetRoomID()
        {
            string sql = string.Format("SELECT RoomID FROM Room WHERE RoomType = '{0}'",
                cboRooms.SelectedItem);
            DataTable roomID = GetData(sql);
        }
        #endregion

        #region Startup
        private void SetTexboxReadOnly(bool state)
        {
            txtFirstName.ReadOnly = state;
            txtLastName.ReadOnly = state;
            dtpStart.Enabled = !state;
            dtpEnd.Enabled = !state;
            txtRoomNumber.ReadOnly = state;
            txtRate.ReadOnly = state;
            chkParking.Enabled = !state;
            cboRooms.Enabled = !state;
        }

        private void FillRoom()
        {
            cboRooms.Items.Add("Double");
            cboRooms.Items.Add("Queen");
            cboRooms.Items.Add("2 Double");
            cboRooms.Items.Add("2 Queen");
            cboRooms.Items.Add("King");
            cboRooms.Items.Add("Penthouse Suite");

            dtRooms = GetData("SELECT * FROM Room");
        }
        private void FillHotelDropdown()
        {
            dtHotels = GetData("SELECT HotelID, Name FROM Hotel");
            DataRow row = dtHotels.NewRow();
            row["HotelID"] = DBNull.Value;
            //row["Name"] = "--Select a Hotel--";
            dtHotels.Rows.InsertAt(row, 0);

            //cboHotels.SelectedItem = "Hotel 1";
            cboHotels.DisplayMember = "Name";
            cboHotels.ValueMember = "HotelID";
            cboHotels.DataSource = dtHotels;
        }

        private void LoadGuests()
        {
            dtGuests = GetData("SELECT FirstName, LastName, Preferred FROM Guest");
        }

        private void LoadBookings()
        {
            dtBookings = GetData("SELECT * FROM Booking");
        }

        private void PopulateFields()
        {
            txtFirstName.Text = dtGuests.Rows[currentRecord]["FirstName"].ToString();
            txtLastName.Text = dtGuests.Rows[currentRecord]["LastName"].ToString();
            dtpStart.Text = dtBookings.Rows[currentRecord]["StartDate"].ToString();
            dtpEnd.Text = dtBookings.Rows[currentRecord]["EndDate"].ToString();
            chkParking.Checked = (bool)dtBookings.Rows[currentRecord]["RequireParking"];
            txtRate.Text = dtRooms.Rows[currentRecord]["Rate"].ToString();
            txtRoomNumber.Text = dtRooms.Rows[currentRecord]["RoomNumber"].ToString();
            cboHotels.SelectedItem = dtHotels.Rows[currentRecord]["Name"].ToString();
            cboRooms.SelectedItem = dtRooms.Rows[currentRecord]["RoomType"].ToString();
            chkPreferred.Checked = (bool)dtGuests.Rows[currentRecord]["Preferred"];
            DisplayCurrentPosition();
        }
        private void DisplayCurrentPosition()
        {
            myParent.tssThree.Text = "Position: " + (currentRecord + 1).ToString() + " of " + dtGuests.Rows.Count;
        }

        //private void Join()
        //{
        //    string sql = GetData("SELECT GuestID");
        //}

        #endregion

        #region Navigation
        #region Guest
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (GuestCurrentRecord != dtGuests.Rows.Count - 1)
            {
                GuestCurrentRecord++;
            }
            PopulateFields();
            DisplayCurrentPosition();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (GuestCurrentRecord > 0)
            {
                GuestCurrentRecord--;
            }
            PopulateFields();
            DisplayCurrentPosition();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            GuestCurrentRecord = dtGuests.Rows.Count - 1;
            PopulateFields();
            DisplayCurrentPosition();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            GuestCurrentRecord = 0;
            PopulateFields();
            DisplayCurrentPosition();
        }
        #endregion
        #region Bookings
        private void btnPreviousBook_Click(object sender, EventArgs e)
        {
            if (currentRecord > 0)
            {
                currentRecord--;
            }
            PopulateFields();
            DisplayCurrentPosition();
        }

        private void btnFirstBook_Click(object sender, EventArgs e)
        {
            currentRecord = 0;
            PopulateFields();
            DisplayCurrentPosition();
        }

        private void btnNextBook_Click(object sender, EventArgs e)
        {
            if (currentRecord != dtGuests.Rows.Count - 1)
            {
                currentRecord++;
            }
            PopulateFields();
            DisplayCurrentPosition();
        }

        private void btnLastBook_Click(object sender, EventArgs e)
        {
            currentRecord = dtGuests.Rows.Count - 1;
            PopulateFields();
            DisplayCurrentPosition();
        }
        #endregion
        #endregion

        #region DataAccess
        private DataTable GetData(string sqlstmt)
        {
            SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnString);
            DataTable dtFull = new DataTable();
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlstmt, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dtFull);
            }
            return dtFull;
        }
        private int SendData(string sqlstmt)
        {
            int numRecordsAffected = 0;
            SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnString);
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlstmt, conn);
                conn.Open();
                numRecordsAffected = cmd.ExecuteNonQuery();
                conn.Close();
            }
            return numRecordsAffected;
        }

        #endregion

        #region Add/Edit/Delete
        private void btnBook_Click(object sender, EventArgs e)
        {
            addBook = true;
            SetButtons(false);
            myParent.tssFour.Text = "Add Record in Progress...";
            ResetForm();
            SetTexboxReadOnly(false);
        }

        private void btnDeleteBook_Click(object sender, EventArgs e)
        {
            deleteBook = true;
            SetButtons(false);
            myParent.tssFour.Text = "Delete Record in Progress...";
        }

        private void btnEditBook_Click(object sender, EventArgs e)
        {
            editBook = true;
            SetButtons(false);
            myParent.tssFour.Text = "Edit Record in Progress...";
            ResetForm();
            SetTexboxReadOnly(false);


        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetButtons(true);
            PopulateFields();
            deleteBook = false;
            addBook = false;
            editBook = false;
            myParent.tssFour.Text = "OK";
            SetTexboxReadOnly(true);
        }

        private void btnSaveBook_Click(object sender, EventArgs e)
        {

        }

        private string BuildSqlStatement()
        {
            if (addBook == true)
            {
                //add guest
                return string.Format("INSERT INTO Booking (StartDate, EndDate, RoomID, RequireParking, TotalCharge) " +
                    "VALUES({0}, {1}, {2}, {3}, {4})",
                    dtpStart.Value,
                    dtpEnd.Value,
                    GetRoomID(),
                    chkParking.Checked ? "1" : "0",
                    CalculateCharge()
                    );
            }
            else if (editBook == true)
            {
                //edit guest info
                return string.Format(
                    );
            }
            else if (deleteBook == true)
            {
                //delete guest
                return string.Format("DELETE FROM Guest WHERE GuestID = '{0}'",
                    GetCurrentGuestId());
            }
            else
            {
                //temporary.It had to return something
                string ah = "ahhhh";
                return ah;
            }
        }
        #endregion


    }
}
