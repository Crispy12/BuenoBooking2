﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BuenoBookings
{
    public partial class AvailableRooms : Form
    {
        private Form1 myParent;
        private DataTable dtRooms;
        private int currentRecord = 0;
        public AvailableRooms(Form1 p)
        {
            myParent = p;
            InitializeComponent();
        }
        private void AvailableRooms_Load(object sender, EventArgs e)
        {
            FillRoomDropdown();
            FillHotelDropdown();
            PopulateFileds();
        }
        #region Startup
        private void FillRoomDropdown()
        {
            cboRoomTypes.Items.Add("Double");
            cboRoomTypes.Items.Add("Queen");
            cboRoomTypes.Items.Add("2 Double");
            cboRoomTypes.Items.Add("2 Queen");
            cboRoomTypes.Items.Add("King");
            cboRoomTypes.Items.Add("Penthouse Suite");
        }
        private void LoadRooms()
        {

        }
        private void PopulateFileds()
        {
            txtParkingRate.Text = dtRooms.Rows[currentRecord]["ParkingRate"].ToString();
            txtRate.Text = dtRooms.Rows[currentRecord]["Rate"].ToString();
            txtRoomNumber.Text = dtRooms.Rows[currentRecord]["RoomNumber"].ToString();
        }
        private void FillHotelDropdown()
        {
            DataTable dtHotels = GetData("SELECT HotelID, Name FROM Hotel");
            DataRow row = dtHotels.NewRow();
            row["HotelID"] = DBNull.Value;
            row["Name"] = "--Select a Hotel--";
            dtHotels.Rows.InsertAt(row, 0);

            cboHotels.DisplayMember = "Name";
            cboHotels.ValueMember = "HotelID";
            cboHotels.DataSource = dtHotels;
        }

        #endregion

        #region DataAccess
        private DataTable GetData(string sqlstmt)
        {
            SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnString);
            DataTable dtFull = new DataTable();
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlstmt, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dtFull);
            }
            return dtFull;
        }
        private int SendData(string sqlstmt)
        {
            int numRecordsAffected = 0;
            SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnString);
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlstmt, conn);
                conn.Open();
                numRecordsAffected = cmd.ExecuteNonQuery();
                conn.Close();
            }
            return numRecordsAffected;
        }

        #endregion


    }
}
