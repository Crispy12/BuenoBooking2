﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuenoBookings
{
    public partial class Reports : Form
    {
        private Form1 myParent;

        public Reports(Form1 p)
        {
            myParent = p;
            InitializeComponent();
        }

        private void Reports_Load(object sender, EventArgs e)
        {

        }
    }
}
